Estructura de datos 1
