/*@Author: Raul alberto Ortiz Montaño**/




package com.example.paint;

import android.graphics.Path;

public class Dibujar {

    public int color;
    public int strokeWidth;
    public Path path;

    public Dibujar(int color, int strokeWidth, Path path) {

        this.color = color;
        this.strokeWidth = strokeWidth;
        this.path = path;

    }

}